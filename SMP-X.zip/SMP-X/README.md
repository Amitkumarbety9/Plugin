# SMP-X

All-in-one SMP admin plugin for Paper 1.21+. Everything runs through `/smp`.

## Build

Requires Java 21 and Maven.

    mvn package

The jar is created at `target/SMP-X-1.0.0.jar`. Put it in your server's `plugins` folder.

## Permissions

- `/smp ping` and `/smp playtime` - everyone
- `/smp god` - `smpx.owner` (OP by default)
- all other commands - `smpx.admin` (OP by default)

## Commands

| Command | What it does |
|---|---|
| `/smp` | Shows all commands |
| `/smp ban <player> [time]` | Ban for a time: `30s`, `10m`, `2h`, `1d`, or `perm` |
| `/smp unban <player>` | Unban |
| `/smp setjail` | Set the jail at your location |
| `/smp jail <player> [time]` | Jail a player (permanent if no time) |
| `/smp unjail <player>` | Release from jail |
| `/smp freeze <player>` / `unfreeze <player>` | Freeze / unfreeze |
| `/smp god [player]` | No one can hit you (owner only) |
| `/smp feed [player]` | Fill hunger |
| `/smp heal [player]` | Full health |
| `/smp fly [player]` | Toggle flight |
| `/smp invsee <player>` | Open their inventory |
| `/smp enderchest <player>` | Open their ender chest |
| `/smp lightning <player>` | One lightning strike |
| `/smp nick <player> <newname\|reset>` | Change display name (colour codes like `&a` work) |
| `/smp ping [player]` | Ping: green = low, yellow = medium, red = high |
| `/smp kill <player>` | Kill a player |
| `/smp playtime [player]` | Playtime of one player, or all players |
| `/smp keep-inventory <player>` | Toggle keep inventory for that player |
| `/smp keep-xp <player>` | Toggle keep XP for that player |

Data is saved in `plugins/SMP-X/data.yml`.
